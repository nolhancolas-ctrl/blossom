
import Countdown from "@/components/Countdown";
import Scene from "@/components/Scene";
import dynamic from "next/dynamic";

const BuyButton = dynamic(() => import("@/components/ShopifyBuyButton"), { ssr: false });

export default function Home() {
  const launch = "2025-12-01T10:00:00+09:00"; // Modifie pour ta date de lancement

  return (
    <main className="mx-auto max-w-5xl px-4 py-16">
      <header className="mb-12 text-center">
        <h1 className="text-4xl md:text-6xl font-bold tracking-tight">Blossom</h1>
        <p className="mt-3 text-base md:text-lg opacity-80">Livre illustré · plantes · posters · cartes</p>
        <div className="mt-6">
          <Countdown target={launch} />
        </div>
      </header>

      <section className="grid md:grid-cols-2 gap-8 items-center">
        <div className="space-y-4">
          <h2 className="text-2xl font-semibold">Un univers végétal vivant</h2>
          <p className="opacity-80">Aperçu 3D (placeholder) — remplace par un modèle .glb ou une scène signée par ton frère.</p>
          <p className="opacity-80">Inscris-toi pour être prévenu·e de la sortie et des séries limitées de posters.</p>
        </div>
        <Scene />
      </section>

      <section className="mt-16">
        <h2 className="text-2xl font-semibold mb-4">Posters – exemple de bouton d’achat</h2>
        <p className="mb-4 opacity-80">Intégré via Shopify Buy Button sans quitter ton site.</p>
        <BuyButton
          productId="gid://shopify/Product/REPLACE_ME"
          domain="ta-boutique.myshopify.com"
          storefrontToken="REPLACE_ME"
        />
      </section>

      <footer className="mt-24 text-center opacity-60 text-sm">© {new Date().getFullYear()} Blossom</footer>
    </main>
  );
}
