
"use client";
import { useEffect, useMemo, useState } from "react";

function pad(n: number) { return n.toString().padStart(2, "0"); }

export default function Countdown({ target }: { target: string }) {
  const targetDate = useMemo(() => new Date(target).getTime(), [target]);
  const [now, setNow] = useState<number>(Date.now());

  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);

  const diff = Math.max(0, targetDate - now);
  const d = Math.floor(diff / (1000 * 60 * 60 * 24));
  const h = Math.floor((diff / (1000 * 60 * 60)) % 24);
  const m = Math.floor((diff / (1000 * 60)) % 60);
  const s = Math.floor((diff / 1000) % 60);

  return (
    <div className="inline-flex gap-3 text-2xl md:text-4xl font-semibold tracking-wide">
      <Time label="J" value={d} />
      <span>:</span>
      <Time label="H" value={h} />
      <span>:</span>
      <Time label="M" value={m} />
      <span>:</span>
      <Time label="S" value={s} />
    </div>
  );
}

function Time({ label, value }: { label: string; value: number }) {
  return (
    <div className="flex flex-col items-center">
      <span className="tabular-nums">{pad(value)}</span>
      <span className="text-xs opacity-70">{label}</span>
    </div>
  );
}
